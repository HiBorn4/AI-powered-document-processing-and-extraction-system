from paddleocr import PaddleOCR

# Loading the detector and OCR with the previously trained weights
custom_ocr = PaddleOCR(
    use_angle_cls=True,
    # det_model_dir="D:\\Bhavya\\vinplate_main\\my_latest_trained_weights\\text_detection\\en_PP-OCRv3_det\\1\\epoch_25_infer\\Teacher",
    rec_model_dir="weights/en_PP-OCRv4_rec_infer",
    use_gpu=False,
    show_log=False,
    lang='en',
    cls=False,
    bin=True
)


def image_ocr(image):
    # img_shape = image.shape
    result = custom_ocr.ocr(image, det=False, rec=True)
    # print('main result :', result)
    ocr_text = str(result[0][0][0])
    # print("OCR RESULT:", ocr_text)
    return [ocr_text]
    
